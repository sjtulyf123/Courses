/*In android system, we can use ps to see the information of all process, but we cannot use
pstree to see the relationship of those process intuitively like what we can do in Linux. 
So we need a new system call. */

/*The system call takes two arguments and
return the process tree information in a depth-first-search (DFS) order.*/

/*The prototype for my system will be:
int ptree(struct prinfo *buf, int *nr);*/

/*Each system call must be assigned a number. This
system call should be assigned number 356.*/

#include<linux/module.h>
#include<linux/kernel.h>
#include<linux/init.h>
#include<linux/sched.h>
#include<linux/unistd.h>
#include<linux/slab.h>
#include<linux/uaccess.h>

MODULE_LICENSE("Dual BSD/GPL");

#define __NR_ptree 356
static int (*oldcall)(void);

struct prinfo{
	pid_t parent_pid;/*process id of parent*/
	pid_t pid;/*process id*/
	pid_t first_child_pid;/*pid of youngest child*/
	pid_t next_sibling_pid;/*pid of older sibling*/
	long state;/*current state of process*/
	long uid;/*user id of process owner*/
	char comm[64];/*name of program executed*/
};

//copy info. from task struct to our struct
void copy_ptree(struct task_struct *sours, struct prinfo *des)
{
	//copy all necaessary things
	des->parent_pid=(sours->parent) ? sours->parent->pid : 0;
	des->pid=sours->pid;
	des->first_child_pid=list_empty(&(sours->children)) ? 0 : list_entry(sours->children.next,struct task_struct,sibling)->pid;
	des->next_sibling_pid=list_empty(&(sours->sibling)) ? 0 : list_entry(sours->sibling.next,struct task_struct,sibling)->pid;
	des->state=sours->state;
	des->uid=sours->cred->uid;
	get_task_comm(des->comm,sours);
}

void dfs(struct task_struct *cur_task, struct prinfo *buf, int *id)//dfs process
{
	struct list_head *it;//the head of the list
	struct task_struct *q;
	copy_ptree(cur_task, &buf[*id]);//copy the current process
	(*id)++;
	list_for_each(it,&(cur_task->children))//iterations
	{
		q=list_entry(it, struct task_struct,sibling);
		dfs(q,buf,id);
	}//use dfs to find the next process
}

int ptree(struct prinfo *buf, int *nr)
{
	//initalize some parameters and allocate space for buffer
	int number=0;
	struct prinfo *tmp_buf=(struct prinfo *)kmalloc(2048*sizeof(struct prinfo),GFP_KERNEL);
	
	//do dfs process
	//use lock and unlock to protect the process
	read_lock(&tasklist_lock);
	dfs(&init_task,tmp_buf,&number);
	read_unlock(&tasklist_lock);

	if(copy_to_user(nr,&number,sizeof(int)))//deal with exception
	{
		printk(KERN_ERR "Copy error!\n");
		return 1;	
	}

	if(copy_to_user(buf,tmp_buf,2048*sizeof(struct prinfo)))//deal with exception
	{
		printk(KERN_ERR "Copy error!\n");
		return 1;	
	}

	//clear
	kfree(tmp_buf);
	return 0;
}

static int ptree_init(void)
{
	long *syscall=(long*)0xc000d8c4;
	oldcall=(int(*)(void))(syscall[__NR_ptree]);
	syscall[__NR_ptree]=(unsigned long)ptree;
	printk(KERN_INFO "mudule ptree load!\n");
	return 0;
}

static void ptree_exit(void)
{
	long *syscall=(long*)0xc000d8c4;
	syscall[__NR_ptree]=(unsigned long)oldcall;
	printk(KERN_INFO "module ptree exit!\n");
}
module_init(ptree_init);
module_exit(ptree_exit);
