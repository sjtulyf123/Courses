/*Burger Buddies Problem
It is a synchronization problem.*/
/*We have some restrictions:*/
/*Cooks, Cashiers, and Customers are each modeled as a thread.*/
/*Cashiers sleep until a customer is present.*/
/*A Customer approaching a cashier can start the order process.*/
/*A Customer cannot order until the cashier is ready.*/
/*Once the order is placed, a cashier has to get a burger from the rack.*/
/*If a burger is not available, a cashier must wait until one is made.*/
/*The cook will always make burgers and place them on the rack.*/
/*The cook will wait if the rack is full.*/
/*In this code, we set the maximum of each people is 1000*/
#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include<semaphore.h>
#include<pthread.h>
#include<string.h>

sem_t sem_rack, sem_burger, sem_order, sem_cashier;//define some semaphores

int num_customer=0;//the number of customers

void *customer(void *id)//customer process
{
	int k=*(int *)id;//the id of the customer
	sleep(rand()%10);//randomly enter
	printf("Customer[%d] comes.\n",k);
	sem_wait(&sem_cashier);//wake up the cashier
	sem_post(&sem_order);//make an order
	return;
}
void *cook(void *id)//cook process
{
	int k=*(int *)id;//id of the cook
	while(num_customer!=0)//there are still some customers to be entered
	{
		sem_wait(&sem_rack);//wait the rack becomes not full
		sleep(1);//make burger
		sem_post(&sem_burger);//put the burger on the rack
		printf("Cook[%d] makes a burger.\n",k);
	}
	return;
}
void *cashier(void *id)//cashier process
{
	int k=*(int *)id;//id of the cashier
	while(num_customer!=0)
	{
		sem_wait(&sem_order);//wait the order
		printf("Cashier[%d] accepts an order.\n",k);
		sem_wait(&sem_burger);//take a burger from the rack
		sem_post(&sem_rack);//the rack lose a burger
		sleep(1);//post it to the customer
		num_customer--;//customer receive the burger
		printf("Cashier[%d] takes a burger to a customer.\n",k);
		sem_post(&sem_cashier);//cashier finish his task
	}
	return;
}

int main(int argc, char *argv[])
{
	srand(time(0));//randomly define the customer coming time
	if(argc!=5)//exceptions:input error
	{
		printf("Invalid input!\n");
		printf("The correct format should be:\n");
		printf("#Cooks, #Cashiers, #Customers, #Racksize.\n");
		return 1;
	}

	//initialize
	int i;
	pthread_t t_cook[1000],t_customer[1000],t_cashier[1000];//thread
	int id_cook[1000],id_customer[1000],id_cashier[1000];//the id of thread
	for(i=0;i<1000;++i)//the id starts from 1
	{
		id_cook[i]=i+1;
		id_customer[i]=i+1;
		id_cashier[i]=i+1;
	}

	//input number
	int num_cook,numcustomer,num_cashier,racksize;
	num_cook=atoi(argv[1]);
	num_cashier=atoi(argv[2]);
	numcustomer=atoi(argv[3]);
	racksize=atoi(argv[4]);
	num_customer=numcustomer;
	if(num_cook>1000||num_cashier>1000||num_customer>1000||racksize>1000)//input number is larger than what we assume
	{
		printf("The input number is larger than 1000!\n");
		return 1;
	}//exceptions
	
	printf("Cooks[%d],Cashiers[%d],Customers[%d],Rack[%d].\n",num_cook,num_cashier,num_customer,racksize);
	printf("Begin run.\n");
	
	//initialize semaphores
	sem_init(&sem_rack,0,racksize);
	sem_init(&sem_burger,0,0);
	sem_init(&sem_order,0,0);
	sem_init(&sem_cashier,0,num_cashier);

	//create 3 kinds of threads
	int res;
	for(i=0;i<num_cook;++i)//create cook threads
	{
		res=pthread_create(&t_cook[i],NULL,cook,&id_cook[i]);
		if(res!=0)
		{printf("Fail to create a cook!\n");return 1;}
	}
	
	for(i=0;i<num_cashier;++i)//create cashier process
	{
		res=pthread_create(&t_cashier[i],NULL,cashier,&id_cashier[i]);
		if(res!=0)
		{printf("Fail to create a cashier!\n");return 1;}
	}

	for(i=0;i<num_customer;++i)//create customer process
	{	
		res=pthread_create(&t_customer[i],NULL,customer,&id_customer[i]);
		if(res!=0)
		{printf("Fail to create a customer!\n");return 1;}
	}
	
	//add the created thread to the current flow
	for(i=0;i<num_cook;++i) pthread_join(t_cook[i],NULL);
	for(i=0;i<num_cashier;++i) pthread_join(t_cashier[i],NULL);
	for(i=0;i<num_customer;++i) pthread_join(t_customer[i],NULL);

	//clear semaphores
	sem_destroy(&sem_rack);
	sem_destroy(&sem_cashier);
	sem_destroy(&sem_burger);
	sem_destroy(&sem_order);
	return 0;
}
