/*This is the test of the system call*/

/*Print the entire process tree (in DFS order)
using tabs to indent children with respect to
their parents.*/

/*The output format of every process is:
printf( correct number of \t );
printf("%s,%d,%ld,%d,%d,%d,%d\n", p.comm, p.pid, p.state,
p.parent_pid, p.first_child_pid, p.next_sibling_pid, p.uid);*/

#include"stdio.h"
#include<stdlib.h>
#include<string.h>

struct prinfo{
	pid_t parent_pid;/*process id of parent*/
	pid_t pid;/*process id*/
	pid_t first_child_pid;/*pid of youngest child*/
	pid_t next_sibling_pid;/*pid of older sibling*/
	long state;/*current state of process*/
	long uid;/*user id of process owner*/
	char comm[64];/*name of program executed*/
};

int main(int argc, char *argv[])
{
	int stack[300];
	memset(stack,0,300*sizeof(int));
	int counttabs[300];//count how many tabs should be printed
	memset(counttabs,0,300*sizeof(int));
	int nr=0;
	int top=0;//top of the stack
	int i=0;
	struct prinfo *buf=(struct prinfo*) malloc(2048*sizeof(struct prinfo));
	syscall(356,buf,&nr);//call ptree
	//calculate how many tabs should be printed
	for(i=0;i<nr;++i)
	{
		if(i==nr-1)
			buf[i].next_sibling_pid=0;
		if(i!=nr-1 && buf[i].first_child_pid!=buf[i+1].pid && buf[i].next_sibling_pid!=buf[i+1].pid)
			buf[i].next_sibling_pid=0;
		if(buf[i].pid==buf[stack[top-1]].first_child_pid||top==0)//there should be a tab
			{stack[top]=i;top++;}
		else
		{
			while(buf[stack[top-1]].next_sibling_pid!=buf[i].pid)
			{
				top=top-1;
				buf[stack[top]].next_sibling_pid=0;
			}
		stack[top-1]=i;//store i to the stack
		}
		counttabs[i]=top-1;//it is the offset of i with the first process
	}
	//print ptree
	int j=0;
	for(i=0;i<nr;++i)
	{
		for(j=0;j<counttabs[i];++j)//print tabs
			printf("\t");
		printf("%s,%d,%ld,%d,%d,%d,%ld\n", buf[i].comm, buf[i].pid, buf[i].state, buf[i].parent_pid, buf[i].first_child_pid, buf[i].next_sibling_pid, buf[i].uid);
	}
	free(buf);//free the space
	return 0;
}
