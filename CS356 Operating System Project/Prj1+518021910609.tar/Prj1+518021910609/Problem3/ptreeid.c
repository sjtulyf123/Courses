/*Generate a new process and output
“StudentIDParent” with PID, then
generates its children process, which
output “StudentIDChild” with PID.*/

/*It uses execl to execute ptree in the child
process,and shows the connection between
above two processes.*/

#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<sys/wait.h>

int main(int argc, char* argv[])
{
	pid_t childpid;
	childpid=fork();
	if(childpid==0)//it is a child process
	{
		printf("518021910609 Child PID:%d\n",getpid());//get the pid
		printf("Executing child ptree process!\n");
		execl("/data/misc/ptreetestARM","ptreetestARM",NULL);//execute our new syscall file
		_exit(EXIT_SUCCESS);	
	}
	else if(childpid>0)//it is a parent process
	{
		printf("518021910609 Parent PID:%d\n",getpid());
		wait(NULL);//wait for child process to finish
		
	}
	else//error
	{
		printf("Fork error!\n");//error message
		exit(EXIT_FAILURE);
	}
	return 0;
}
