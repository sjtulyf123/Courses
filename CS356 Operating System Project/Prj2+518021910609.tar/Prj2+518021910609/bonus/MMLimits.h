// This file is the definition of structure MMLimits
#ifndef _MMLIMITS_H
#define _MMLIMITS_H

#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/sched.h>
#include <linux/unistd.h>

struct MMLimits{
	uid_t uid[2048];//save uid
	unsigned long mm_max[2048];//save mm limits
	int num;//current number of users that have set mmlimits
};

extern struct MMLimits mm_limits;

#endif
