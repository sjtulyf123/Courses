// Name: Yifan Liu
// ID:   518021910609
#include <getopt.h>
#include <stdlib.h>
#include <unistd.h>
#include "cachelab.h"
#include <stdio.h>
#include <strings.h>
#include <string.h>

#define LRUMAX 1000

typedef struct{
	int valid;//valid bit
	int LRU;//lru number
	int tag;//tag number
} Line;//the struct of one line in cache

typedef struct{
	Line* lines;//many lines in a set
} Set;//the struct of one set in cache

typedef struct{
	int set_cnt;  //the number of sets
	int line_cnt; //the number of lines
	Set* sets;     //many sets
} Scache;//struct of simulate cache


//output variables: misses, hits and evictions
int miss_count;
int hit_count;
int eviction_count;

//print help messages
void printHelp()
{
	printf("Usage: ./csim-ref [-hv] -s <s> -E <E> -b <b> -t <tracefile>\n");
	printf("-h: Optional help flag that prints usage info\n");
	printf("-v: Optional verbose flag that displays trace info\n");
	printf("-s <s>: Number of set index bits\n");
	printf("-E <E>: Associativity (number of lines per set)\n");
	printf("-b <b>: Number of block bits\n");
	printf("-t <tracefile>: Name of the valgrind trace to replay\n");
}

//check whether the command is valid

void checkOptarg(char *curOptarg){
    if(curOptarg[0]=='-'){
        printf("Wrong command format\n");
        printHelp();
        exit(0);
    }
}


//get variables from command

int get_Opt(int argc,char **argv,int *s,int *E,int *b,char *traceName,int *Verbose_mode){
    int c;
    while((c = getopt(argc,argv,"hvs:E:b:t:"))!=-1)
    {
        switch(c)
        {
        case 'v':
            *Verbose_mode = 1;
            break;
        case 's':
            checkOptarg(optarg);
            *s = atoi(optarg);
            break;
        case 'E':
            checkOptarg(optarg);
            *E = atoi(optarg);
            break;
        case 'b':
            checkOptarg(optarg);
            *b = atoi(optarg);
            break;
        case 't':
            checkOptarg(optarg);
            strcpy(traceName,optarg);
            break;
        case 'h':
        default:
            printHelp();
            exit(0);
        }
    }
    return 1;
}

//initial cache
void init_cache(int s,int E,int b, Scache *cache)
{
	//exceptions
	if(s<0)
	{
		printf("sets number must larger than 0\n!");
                exit(0);
	}

	cache->set_cnt=2<<s;
	cache->line_cnt=E;
	cache->sets=(Set *)malloc(cache->set_cnt * sizeof(Set));//initial cache
	
	int i,j;
	for(i=0;i<cache->set_cnt;++i)
	{
		cache->sets[i].lines=(Line *)malloc(E*sizeof(Line));//allocate line space
		
		for(j=0;j<E;++j)//initial lines
		{
			cache->sets[i].lines[j].valid = 0;
            		cache->sets[i].lines[j].LRU = 0;
		}
	}
	return ; 
}

//get set number of current address
int get_set(int addr,int s,int b)
{
	addr=addr>>b;
	int k=(1<<s)-1;
	return addr &k;
}

//get tag number of current address
int get_tag(int addr,int s,int b)
{
	int x=s+b;
	return addr>>x;
}

//update LRU number, current LRU becomes the max number, others -1
void update_LRU(Scache *cache, int setaddr, int current_line)
{
	cache->sets[setaddr].lines[current_line].LRU=LRUMAX;
	int i;
	for(i=0;i<cache->line_cnt;++i)//update other LRU
	{
		if(i!=current_line)
		cache->sets[setaddr].lines[i].LRU--;
	}
}

//check whether current data is missing in cache
int miss_checking(Scache *cache,int setaddr,int tagaddr)
{
	int miss_flag=1;
	int i;
	for(i=0;i<cache->line_cnt;++i)
	{
		if(cache->sets[setaddr].lines[i].valid==1 && cache->sets[setaddr].lines[i].tag==tagaddr)//not miss
		{
			miss_flag=0;
			update_LRU(cache, setaddr, i);
		}
	}
	return miss_flag;
}

//find smallest LRU to do replacement
int find_smallest_LRU(Scache *cache,int setaddr)
{
	int target_line=0;//the smallest LRU's index
	int i;
	int min_LRU=LRUMAX;//smallest LRU
	for(i=0;i<cache->line_cnt;++i)//find
	{
		if(cache->sets[setaddr].lines[i].LRU < min_LRU)//update smallest LRU
		{
			target_line=i;
			min_LRU=cache->sets[setaddr].lines[i].LRU;
		}
	}
	return target_line;
}

//check whether the cache is full and need replacement
int cache_full(Scache *cache, int setaddr, int tagaddr)
{
	int full_flag=1;
	int i;
	//check full or not
	for(i=0;i<cache->line_cnt;++i)
	{
		if(cache->sets[setaddr].lines[i].valid==0)//there is an empty space
		{
			full_flag=0;
			break;
		}
	}

	if(full_flag==0)//not full
	{
		cache->sets[setaddr].lines[i].valid=1;//update valid bits
		cache->sets[setaddr].lines[i].tag=tagaddr;//update tag
		update_LRU(cache, setaddr,i);
		
	}
	else//cache is full
	{
		int eviction_line;
		eviction_line=find_smallest_LRU(cache,setaddr);//find the least recent used data
		cache->sets[setaddr].lines[eviction_line].valid=1;//update valid bits
		cache->sets[setaddr].lines[eviction_line].tag=tagaddr;//update tag
		update_LRU(cache,setaddr,eviction_line);
	}
	return full_flag;
}

//load operation
void load_op(Scache *cache,int addr,int sizee,int setaddr,int tagaddr,int Verbose_mode)
{
	if(miss_checking(cache,setaddr,tagaddr)==1)//there is a miss
	{
		miss_count++;
		if(Verbose_mode==1)
			printf("miss ");
		if(cache_full(cache,setaddr,tagaddr)==1)//the cache is full and need eviction
		{
			eviction_count++;
			if(Verbose_mode==1)
				printf("eviction ");
		}
	}
	else//hit
	{
		hit_count++;
       		if(Verbose_mode==1) printf("hit ");
	}
}

//store operation
void store_op(Scache *cache,int addr,int sizee,int setaddr,int tagaddr,int Verbose_mode)
{
	load_op(cache,addr,sizee,setaddr,tagaddr,Verbose_mode);
}

//modify operation
void modify_op(Scache *cache,int addr,int sizee,int setaddr,int tagaddr,int Verbose_mode)
{
	load_op(cache,addr,sizee,setaddr,tagaddr,Verbose_mode);
	store_op(cache,addr,sizee,setaddr,tagaddr,Verbose_mode);
}

int main(int argc,char **argv)
{
	int s,E,b=0;
	int Verbose_mode=0;
	miss_count=0;
	hit_count=0;
	eviction_count=0;
	int addr,sizee;
	
	Scache cache;
	
	char cur_filename[100];
	char opt[10];

	get_Opt(argc,argv,&s,&E,&b,cur_filename,&Verbose_mode);//get variables from command
	init_cache(s,E,b,&cache);//initial cache sim
	FILE *trace=fopen(cur_filename,"r");//open file and execute

	while(fscanf(trace,"%s %x,%d",opt,&addr,&sizee)!=EOF)
	{
		if(strcmp(opt,"I")==0) continue;//jump I line
		int setaddr = get_set(addr,s,b);
        	int tagaddr = get_tag(addr,s,b);
		if(Verbose_mode==1)
			printf("%s %x,%d ",opt,addr,sizee);
		if(strcmp(opt,"S")==0)//store operation
			store_op(&cache,addr,sizee,setaddr,tagaddr,Verbose_mode);
		if(strcmp(opt,"L")==0)//load operation
			load_op(&cache,addr,sizee,setaddr,tagaddr,Verbose_mode);
		if(strcmp(opt,"M")==0)//modify operation
			modify_op(&cache,addr,sizee,setaddr,tagaddr,Verbose_mode);
		if(Verbose_mode==1) 
			printf("\n");
	}
	printSummary(hit_count, miss_count, eviction_count);
	return 0;
}



